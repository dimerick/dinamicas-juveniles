<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXNivelEducativo extends Model {

    protected $table = 'grupo_x_nivel_educativo';
    public $timestamps = false;

}
