<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class FrecuenciaRelacion extends Model {

    protected $table = 'frecuencia_relacion';

}
