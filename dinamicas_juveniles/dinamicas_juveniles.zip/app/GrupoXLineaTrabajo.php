<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXLineaTrabajo extends Model {

    protected $table = 'grupo_x_linea_trabajo';
    public $timestamps = false;

}
