<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class ProcesoInteres extends Model {

    protected $table = 'proceso_interes';

}
