<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LineaTrabajo extends Model
{
    protected $table = 'linea_trabajo';
}
