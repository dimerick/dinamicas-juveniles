<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXCondicionDificultad extends Model {

    protected $table = 'grupo_x_condicion_dificultad';
    public $timestamps = false;

}
