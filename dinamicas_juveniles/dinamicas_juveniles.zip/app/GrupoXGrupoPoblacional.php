<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXGrupoPoblacional extends Model {

    protected $table = 'grupo_x_grupo_poblacional';
    public $timestamps = false;

}
