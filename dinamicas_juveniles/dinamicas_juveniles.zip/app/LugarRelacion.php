<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class LugarRelacion extends Model {

    protected $table = 'lugar_relacion';

}
