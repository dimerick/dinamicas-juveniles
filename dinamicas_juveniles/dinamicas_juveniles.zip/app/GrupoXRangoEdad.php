<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXRangoEdad extends Model {

    protected $table = 'grupo_x_rango_edad';
    public $timestamps = false;

}
