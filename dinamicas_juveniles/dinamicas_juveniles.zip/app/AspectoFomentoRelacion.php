<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class AspectoFomentoRelacion extends Model {

    protected $table = 'aspecto_fomento_relacion';

}
