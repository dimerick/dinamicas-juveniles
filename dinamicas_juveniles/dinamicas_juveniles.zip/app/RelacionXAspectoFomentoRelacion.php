<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class RelacionXAspectoFomentoRelacion extends Model {

    protected $table = 'relacion_x_aspecto_fomento_relacion';
    public $timestamps = false;

}
