<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class CondicionAfinidad extends Model {

    protected $table = 'condicion_afinidad';

}
