<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXApoyo extends Model {

    protected $table = 'grupo_x_apoyo';
    public $timestamps = false;

}
