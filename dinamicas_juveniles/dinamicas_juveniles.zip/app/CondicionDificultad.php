<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class CondicionDificultad extends Model {

    protected $table = 'condicion_dificultad';

}
