<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Relacion extends Model {

    protected $table = 'relacion';

}
