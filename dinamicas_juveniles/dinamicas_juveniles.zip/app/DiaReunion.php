<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class DiaReunion extends Model {

    protected $table = 'dia_reunion';

}
