<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Estrato extends Model {

    protected $table = 'estrato';

}
