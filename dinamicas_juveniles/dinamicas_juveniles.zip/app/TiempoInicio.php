<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TiempoInicio extends Model
{
    protected $table = 'tiempo_inicio';
}
