<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class PosibleRelacion extends Model {

    protected $table = 'posible_relacion';

}
