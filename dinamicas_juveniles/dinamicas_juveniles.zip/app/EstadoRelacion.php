<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EstadoRelacion extends Model
{
    protected $table = 'estado_relacion';
}
