<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RangoEdad extends Model
{
    protected $table = 'rango_edad';
}
