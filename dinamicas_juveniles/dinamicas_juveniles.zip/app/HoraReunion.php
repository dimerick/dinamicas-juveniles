<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class HoraReunion extends Model {

    protected $table = 'hora_reunion';

}
