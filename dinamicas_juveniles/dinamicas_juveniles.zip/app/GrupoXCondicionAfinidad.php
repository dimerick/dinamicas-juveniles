<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXCondicionAfinidad extends Model {

    protected $table = 'grupo_x_condicion_afinidad';
    public $timestamps = false;

}
