<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoXProcesoInteres extends Model {

    protected $table = 'grupo_x_proceso_interes';
    public $timestamps = false;

}
