<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoPoblacional extends Model
{
    protected $table = 'grupo_poblacional';
    protected $guarded = ['id'];
}
