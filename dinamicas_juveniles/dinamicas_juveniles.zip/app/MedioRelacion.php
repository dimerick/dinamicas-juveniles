<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class MedioRelacion extends Model {

    protected $table = 'medio_relacion';

}
