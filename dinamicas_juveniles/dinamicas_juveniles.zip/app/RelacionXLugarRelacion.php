<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class RelacionXLugarRelacion extends Model {

    protected $table = 'relacion_x_lugar_relacion';
    public $timestamps = false;

}
