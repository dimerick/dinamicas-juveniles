@extends('template')
@section('content')
    <div class="col-sm-6 col-sm-offset-3 form-box">

        <div class="alert alert-success">¡MUCHAS GRACIAS!</div>
        <a href="/comuna5" class="btn btn-primary btn-lg active" role="button">Crear un nuevo registro</a>

    </div>
@stop